// BEGIN
export const flatten = (massive) => {
    let flattenMassive = [];
    return flattenMassive.concat(...massive);
}
// END